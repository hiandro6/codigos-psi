CREATE TABLE IF NOT EXISTS tb_usuarios (
    usu_id INTEGER PRIMARY KEY AUTOINCREMENT,
    usu_nome TEXT NOT NULL,
    usu_email TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS tb_livros (
    liv_id INTEGER PRIMARY KEY AUTOINCREMENT,
    liv_titulo TEXT NOT NULL,
    liv_usu_id INTEGER NOT NULL,
    FOREIGN KEY(liv_usu_id) REFERENCES tb_usuarios(usu_id)
);

CREATE TABLE IF NOT EXISTS tb_emprestimos (
    emp_id INTEGER PRIMARY KEY AUTOINCREMENT,
    -- emp_data_devolucao DATE NOT NULL,
    emp_usu_id INTEGER NOT NULL,
    emp_liv_id INTEGER NOT NULL,
    FOREIGN KEY(emp_usu_id) REFERENCES tb_usuarios(usu_id),
    FOREIGN KEY(emp_liv_id) REFERENCES tb_livros(liv_id)
);

SELECT * FROM tb_emprestimos;