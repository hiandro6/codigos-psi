
all = [
    'books',
    'users'
    'emprestimo'
]