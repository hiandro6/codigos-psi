from flask_login import UserMixin
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship
from sqlalchemy import String, Date, ForeignKey
 
class Base(DeclarativeBase):
    pass

class User(UserMixin, Base):
    __tablename__ = 'usuarios'
    id:Mapped[int] = mapped_column(primary_key=True)
    nome:Mapped[str] = mapped_column(String(100), nullable = False)
    email:Mapped[str] = mapped_column(String(200), nullable= False)
    senha:Mapped[str] = mapped_column(String(200), nullable= False)
    noticias:Mapped[list['Noticia']] = relationship('Noticia', back_populates='usuario')

    def get_id(self):
        return self.id
    
    def __repr__(self):
        return f"nome: {self.nome} email: {self.email}"
    
    def __init__(self, nome, email, senha):
        self.nome = nome
        self.email = email
        self.senha = senha

class Noticia(Base): 
    __tablename__ = 'noticias'
    id:Mapped[int] = mapped_column(primary_key=True)
    titulo:Mapped[str] = mapped_column(String(100), nullable = False)
    descricao:Mapped[str] = mapped_column(String(200), nullable= False)
    data:Mapped[str] = mapped_column(Date, nullable= False)
    usu_id:Mapped[int] = mapped_column(ForeignKey('usuarios.id'))

    usuario:Mapped['User'] = relationship('User', back_populates='noticias')

    def get_id(self):
        return self.id
    
    def __repr__(self):
        return f"titulo: {self.titulo} data: {self.data} usuario: {self.usuario.nome}"
    
    def __init__(self, titulo, descricao, data, usu_id):
        self.titulo = titulo
        self.descricao = descricao
        self.data = data
        self.usu_id = usu_id
