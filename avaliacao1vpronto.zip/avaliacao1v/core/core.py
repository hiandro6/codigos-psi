from flask import Blueprint, render_template, request, redirect, url_for
from flask_login import login_required, current_user
from core.models import User, Noticia
from database.config import session
from datetime import datetime
core = Blueprint('core', 'core', template_folder='templates')

@core.route('/')
def index():
    return render_template('index.html')

@core.route('/users')
@login_required
def users():
    usuarios = session.query(User)
    return render_template('core/users.html', usuarios=usuarios)

@core.route('/news')
@login_required
def news():
    user_id = current_user.id
    # .filter(Noticia.usu_id==user_id)
    noticias = session.query(Noticia).all()
    return render_template('core/index.html', noticias=noticias)

@core.route('/addnoticia', methods = ['POST', 'GET'])
def addnoticia():
    if request.method == 'POST':
        titulo = request.form['titulo']
        data = datetime.strptime(request.form['data'], '%Y-%m-%d').date()
        descricao = request.form['descricao']
        user_id = current_user.id

        noticia = Noticia(titulo, descricao, data, user_id)
        session.add(noticia)
        session.commit()

        return redirect(url_for('core.news'))
    
    else:
        return render_template('core/addnoticia.html')

